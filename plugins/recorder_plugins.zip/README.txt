These plugins files are those from Ogg Vorbis Encoder
application from VLSI:

http://www.vlsi.fi/fileadmin/software/VS10XX/vs1053-vorbis-encoder-170c.zip
http://www.vlsi.fi/fileadmin/software/VS10XX/VorbisEncoder170c.pdf

Consult the encoder manual to check which profile
you prefer.

These .vs files are binaries ready to use by function VSLoadUserCode,
used in vs_init and startRecordOgg class member functions.
They were generated using vs_plg_to_bin.pl script.

Moreto